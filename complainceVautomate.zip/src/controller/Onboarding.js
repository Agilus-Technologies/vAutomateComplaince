
import { v4 as uuidv4 } from 'uuid';
import https from "https";
import logger from '../../logger.js';
// import onboardingModel from "../../model/onboardingModel.js"
import dbo from "../db/conn.js";
import { commonCredentials } from '../helper/dnacHelper.js';
// import setUPModel from '../../model/setup_model.js';
// import inventoryModel from '../../model/inventoryModel.js';
import axios from "axios";
import onboardingModel from '../model/onboardingModel.js';


export const onboardDeviceDetails = async (req, res) => {
    try {
        console.log("aswedrfghj")
        const db_connect = dbo && dbo.getDb();
        let siteData = await db_connect.collection("ms_cmdb_devices").find({}).project({ "region": 1, "site": 1, "floor": 1, "room": 1, "_id": 0 }).toArray();
        if (!siteData || siteData.length == 0) {
            let errorMsg = { data: [], msg: "Data not found,Please insert site details.", status: false }
            logger.error(errorMsg)
            return res.send(errorMsg)
        }

        let setUpDetails = await db_connect.collection('tbl_Package').find({}).project({ "dnac": 1, "_id": 0 }).toArray();
        if (setUpDetails?.length == 0 || setUpDetails[0].dnac?.length == 0) {
            let errorMsg = { data: {}, msg: "Unable to get dnac credentials", status: false }
            logger.error(errorMsg)
            return res.send(errorMsg)
        }

        let dnacUrlss = await db_connect.collection('ms_device').find({ "source": "DNAC" }).project({ "managementIpAddress": 1, "source_url": 1, "_id": 0, host_name: 1 }).toArray();
        console.log("wedrftghj", dnacUrlss)
        if (dnacUrlss && dnacUrlss?.length == 0) {
            let errorMsg = { data: {}, msg: "Unable to get dnac device", status: false }
            logger.error(errorMsg)
            return res.send(errorMsg)
        }
        let obj = {
            siteDetails: siteData,
            dnacDetails: setUpDetails && setUpDetails[0]?.dnac,
            dnacDevice: dnacUrlss
        }
        logger.info({ msg: "Data get successfully", status: true })
        return res.json({ data: obj, msg: "Data get successfully", status: true })


    } catch (err) {
        let errorMsg = { data: [], msg: `Error msg in onboardDeviceDetails:${err}`, status: false }
        logger.error(errorMsg)
        console.log(errorMsg)
    }

};



const checkEmptyKeyNotExist = async (obj) => {
    console.log("obj", obj)
    for (let key in obj) {
        if (obj[key] == null || obj[key] == "")
            return { msg: `Please provide ${obj[key]} value`, status: false };
    }
    return { msg: `Data get successfully`, status: true };
};


const onboardingConfig = async () => {
    try {


    } catch (error) {
        let errorMsg = { msg: `Error msg in onboardingConfig:${error}`, status: false }
        logger.error(errorMsg)
        console.log(errorMsg)
    }
}

export const task_id = async (dnac, url, token) => {
    try {
        let flag = false;
        setTimeout(() => {
            flag = true;
        }, 40000);
        let fileIDKey = "";
        while (!(fileIDKey.includes('fileId')) && flag === false) {
            let task_id_url = dnac + url;
            let headers = { "x-auth-token": token };
            let response = await axios.get(task_id_url, headers = { headers });
            fileIDKey = response.data.response.progress.replace(':', '');
            if (fileIDKey && fileIDKey.includes('fileId')) {
                flag = true
            }
        }
        if (fileIDKey) {
            let file_id = fileIDKey.replace(':', '').replace('fileId', '').replace('{"""', '').replace('"}', '')
            // let file_id = response.data.response.progress.replace(':', '').replace('fileId', '').replace('{"""', '').replace('"}', '')

            return file_id
        }
    } catch (err) {
        console.log('Error in task_id function 155:', err)
        let msg = `Error in task_id 155 : ${err}`
        let msg_output = { "msg": msg, status: false }
        return msg_output;
    }
};

export const final_command = async (dnacUrl, file_id, token, deviceId, command) => {
    try {
        if (file_id === "CLI Runner request creation") {
            console.log("*********** check file_id in cli_command ***********", file_id)
            return { "msg": `invalid fileId:${file_id}` }
        } else {
            let command_url = dnacUrl + "/api/v1/file/" + file_id;
            let headers = { "x-auth-token": token };
            let response = await axios.get(command_url, headers = { headers })
            return response
        }
    } catch (err) {
        console.log("Error in final_command in dnacHelper", err)
        let msg = `EError in final_command in dnacHelper:${err}`
        let msg_output = { "msg": msg, status: false }
        return msg_output;
    }
};

export const interfaces = async (switchUUID, dnacUrl, token) => {
    try {
        const httpsAgent = new https.Agent({
            rejectUnauthorized: false
        });
        let config = {
            method: 'get',
            maxBodyLength: Infinity,
            // url: `${dnacUrl}/dna/intent/api/v1/interface/network-device/53219b68-e9e5-45aa-89d0-84ab9d521540`,
            url: `${dnacUrl}/dna/intent/api/v1/interface/network-device/${switchUUID}`,
            headers: {
                'x-auth-token': token
            },
            httpsAgent: httpsAgent
        };
        return axios.request(config)
            .then((response) => {
                const data = JSON.stringify(response.data);
                // console.log("sdfg", data);
                return data;
            })
            .catch((error) => {
                console.error(error);
                return null;
            });

    } catch (err) {
        console.log(err)
    }
};

export const dnacDeviceInterfaces = async (req, res) => {
    try {
        const { dnacUrl, device } = req.body;
        let commanCredential = await commonCredentials(device, dnacUrl)
        const { token, cli_command_url, AUTH_API_URL, switchUUID, dnacCredentials } = commanCredential
        let interfaceDetails = await interfaces(switchUUID, dnacUrl, token)
        let data = JSON.parse(interfaceDetails)
        if (data && data.length == 0) {
            let errorMsg = { msg: `Unable to get port from device`, status: false }
            logger.error(errorMsg)
            console.log(errorMsg)
        }
        let inter = []
        for (let item of data.response) {
            inter.push({ portName: item.portName })
        }
        res.send(inter)
    } catch (err) {
        let errorMsg = { msg: `Error msg in dnacDeviceInterface:${err}`, status: false }
        logger.error(errorMsg)
        console.log(errorMsg)
    }
};

export const execute_templates = async (template_id, item) => {
    try {
    
        console.log("asdfghj", item)
        let credData = await commonCredentials(item.device, item.dnac);
        const { token, deploy_temp_url, temp_deploy_status_url, switchUUID, dnacCredentials } = credData
        const httpsAgent = new https.Agent({
            rejectUnauthorized: false
        });
        let data = JSON.stringify({
          "templateId": "48967f32-a1de-46a0-a407-84197a6064b8",
          "targetInfo": [
            {
              "id": item.device,
              "type": "MANAGED_DEVICE_IP",
              "params": {
                "param": item.config
              }
            }
          ]
        });
        
        let config = {
          method: 'post',
          maxBodyLength: Infinity,
          url: 'https://10.122.1.25/dna/intent/api/v1/template-programmer/template/deploy',
          headers: { 
            'x-auth-token': token, 
            'Content-Type': 'application/json'
          },
          data : data,
          httpsAgent:httpsAgent
        };
        let deployment_id;
         axios.request(config)
        .then((response) => {
            let deployment_id=JSON.stringify(response.data)
          console.log(JSON.stringify(response.data));
        //   return result;
        })
        .catch((error) => {
          console.log(error);
        });

        console.log("deployment_id",deployment_id)
        













        // https://10.122.1.25/dna/intent/api/v1/template-programmer/template/deploy



        // const httpsAgent = new https.Agent({
        //     rejectUnauthorized: false
        // });

        return axios.request(config)
            .then((response) => {
                const data = JSON.stringify(response.data);
                console.log("sdfg", data);
                return data;
            })
            .catch((error) => {
                console.error(error);
                return null;
            });











        if (deployment_id === "NoneNone of the targets are applicable for the template. Hence not deploying" || deployment_id === "None of the targets are applicable for the template. Hence not deploying") {
            console.log("********** None of the targets are applicable for the template. Hence not deploying  ************")
            let service_now_updates = await serviceNowUpdate(ticket_data, itsmSelectedValue, `pre-check has been excuted successfully.\n Configuration L3 switch has been failed`)
            // let service_now_updates = await service_now_update(ticket_data,"Configuration L3 switch has been failed")
            let obj = {
                msg: "None of the targets are applicable for the template. Hence not deploying",
                status: false
            }
            return obj
        }
        else {
            // console.log("*************** ELSE  *************************)")
            let temp_deploy_status_urls = temp_deploy_status_url + deployment_id
            // console.log("temp_deploy_status_url*****", temp_deploy_status_url)
            let status = "";
            let temp_deploy_status_json = {};
            console.log("**************** Wait**********************")
            await new Promise(resolve => setTimeout(resolve, 20000));
            let deployStatus = ""
            let excuteRes = false
            setTimeout(() => {
                excuteRes = true;
            }, 40000);
            while ((deployStatus !== "SUCCESS" || deployStatus !== "FAILURE") && excuteRes === false) {
                // let headers = { "x-auth-token": token };
                temp_deploy_status_json = await axios.get(temp_deploy_status_urls, headers)
                deployStatus = temp_deploy_status_json.data.devices[0].status
                if (deployStatus === "SUCCESS" || deployStatus === "FAILURE") {
                    excuteRes = true
                }
            }
            await new Promise(resolve => setTimeout(resolve, 20000));
            let updated = await ticketConfigurationUpdate(ticketName, temp_deploy_status_json.data)
            if (temp_deploy_status_json.data && temp_deploy_status_json.data?.status === "FAILURE") {
                let obj = {
                    msg: `configuration Error Status:${temp_deploy_status_json.status}`,
                    status: false
                }
                return obj
            }
            if (temp_deploy_status_json && temp_deploy_status_json?.data?.devices[0]?.status === 'SUCCESS') {
                let data = temp_deploy_status_json?.data?.devices[0]?.realizedClis
                if (ticket_data.fileType === "portTicket") {
                    data = `pre-check has been excuted successfully.\nConfiguration L2  has been excuted successfully`
                } else {
                    data = `pre-check has been excuted successfully.\nConfiguration L3 switch has been excuted successfully`
                }
                data = `Status : ${temp_deploy_status_json?.data?.devices[0]?.status} \n\n Result : ${temp_deploy_status_json?.data?.devices[0]?.realizedClis}`

                let service_now_updates = await serviceNowUpdate(ticket_data, itsmSelectedValue, data)
                return service_now_updates
            }
            else {
                let data = ""
                if (ticket_data.fileType === "portTicket") {
                    data = `pre-check has been excuted successfully.\nConfiguration L2 switch has been failed.`
                } else {
                    data = `pre-check has been excuted successfully.\nConfiguration L3 switch has been failed.`
                }
                let service_now_updates = await serviceNowUpdate(ticket_data, itsmSelectedValue, data)
                console.log('Status for the process is:', temp_deploy_status_json.status)
                let obj = {
                    msg: `Error in:${temp_deploy_status_json.status}`,
                    status: false
                }
                return obj
            }
        }
    } catch (err) {
        console.log("Error in excut_templates in dnacHelper", err)
        let msg = `Error in excut_templates in dnacHelper:${err}`
        let msg_output = { "msg": msg, status: false }
        return msg_output;
    }
};


export const apply_template = async (data) => {
    try {
        let db_connect = dbo && dbo.getDb();
        let template_id = "48967f32-a1de-46a0-a407-84164b8"
        if (template_id) {
            let excute_templte = await execute_templates(template_id, data)
            return excute_templte
        } else {
            console.log("Check Template ID in apply_template function:", template_id)
            let msg = `Check Template ID in apply_template function:${template_id}`
            let msg_output = { "msg": msg, status: false }
            return msg_output;
        }
    } catch (err) {
        console.log("Error in apply_template in dnacHelper:", err)
        let msg = `Error in apply_template in dnacHelper:${err}`
        let msg_output = { "msg": msg, status: false }
        return msg_output;
    }
};

export const configDevicesInDnac = async (req, res) => {
    try {
        const db_connect = dbo && dbo.getDb();
        console.log("aswedrfgth")
        console.log(req.body)

        // const data = req.body
        let datass = {
        "dayOnboardingMethod": "Use Shared Switch (Access Switch - 9300)",
        "peaccessDevice": "Agilus_Router",
        "region": "India",
        "site":"Noida",
        "floor":"4th Floor",
        "ipAddress": "ewferber",
        "serialNo": "efgtrgtr",
        "pnpVlan": "",
        "pnpStar": "",
        "upLinkSwitchInterface": "Custom Port",
        "dnac":"https://10.122.1.25",
        "device":"10.122.1.2",
        "interfaceID": "GigabitEthernet0/1/2",
        "vlanID":24,
        "otherParameter":"sdvdgefdgre"
    }
        if (Object.keys(datass).length == 0) {
        return res.json({
            msg: "Unable to get data from user.",
            status: false

        })
    }
    const config = `interface ${datass.interfaceID}\ndescription ${datass.otherParameter}\nswitchport mode trunk\nswitchport trunk allowed vlan ${datass.otherParameter}\nno shutdown`
    console.log("config", config)
    datass["config"] = config
    let saveData = await db_connect.collection("onboardingdata").insertOne(datass)
  let template_id = "48967f32-a1de-46a0-a407-84164b8"
   let excute_templte = await execute_templates(template_id, datass)
            return excute_templte
    // let apply_temp = await apply_template(datass);

    res.json({ data: datass, status: true })


} catch (err) {
    let errorMsg = { msg: `Error msg in configDevicesInDnac:${err}`, status: false }
    logger.error(errorMsg)
    console.log(errorMsg)
}
};

export const getUnClaimedDevice = async (req, res) => {
    try {
        const { serialNumber, dnacUrl } = req.body;
        console.log("sdfgh", serialNumber)

        if (!serialNumber || !dnacUrl) {
            return res.status(400).json({ msg: "Missing required fields: serialNumber or dnacUrl", status: false });
        }

        // Hardcoded IP for testing (replace with actual source)
        const dummyDeviceIp = "10.3.1.1";

        const credentialsData = await commonCredentials(dummyDeviceIp, dnacUrl);

        if (!credentialsData?.token) {
            return res.status(401).json({ msg: "Failed to fetch token from DNAC", status: false });
        }

        const urlPath = `/dna/intent/api/v1/onboarding/pnp-device?serialNumber=${serialNumber}`;
        const hostName = new URL(dnacUrl).hostname;

        const options = {
            hostname: hostName,
            path: urlPath,
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "X-Auth-Token": credentialsData.token
            },
            rejectUnauthorized: false // Use only in trusted environments with self-signed certs
        };

        const result = await new Promise((resolve, reject) => {
            const req = https.request(options, (res) => {
                let data = [];

                res.on('data', chunk => data.push(chunk));
                res.on('end', () => {
                    try {
                        const responseBody = Buffer.concat(data).toString();
                        const parsed = JSON.parse(responseBody);
                        resolve(parsed);
                    } catch (e) {
                        reject({ msg: "Error parsing response from DNAC", error: e });
                    }
                });
            });


            req.on('error', (e) => {
                reject({ msg: "HTTPS request failed", error: e.message });
            });

            req.end();
        });

        return res.status(200).json({ status: true, data: result });

    } catch (err) {
        console.error("Error in getUnClaimedDevice:", err);
        return res.status(500).json({ msg: "Server error in getUnClaimedDevice", error: err.message, status: false });
    }
};

export const getDnacSites = async (req, res) => {
    try {
        const { dnacUrl } = req.body;

        if (!dnacUrl) {
            return res.status(400).json({ msg: "Missing 'dnacUrl' in request body", status: false });
        }

        // Use dummy IP just to pass to commonCredentials
        const dummyDeviceIp = "10.3.1.1";
        const creds = await commonCredentials(dummyDeviceIp, dnacUrl);

        if (!creds?.token) {
            return res.status(401).json({ msg: "Failed to fetch token from DNAC", status: false });
        }

        const sitePath = "/dna/intent/api/v1/site";
        const hostname = new URL(dnacUrl).hostname;

        const options = {
            hostname,
            path: sitePath,
            method: "GET",
            headers: {
                "X-Auth-Token": creds.token,
                "Content-Type": "application/json"
            },
            rejectUnauthorized: false // Needed for self-signed certs
        };

        const result = await new Promise((resolve, reject) => {
            const req = https.request(options, (res) => {
                const chunks = [];

                res.on('data', chunk => chunks.push(chunk));
                res.on('end', () => {
                    try {
                        const responseBody = Buffer.concat(chunks).toString();
                        const parsed = JSON.parse(responseBody);
                        resolve(parsed);
                    } catch (err) {
                        reject({ msg: "Error parsing response from DNAC", error: err });
                    }
                });
            });

            req.on('error', (e) => {
                reject({ msg: "HTTPS request failed", error: e.message });
            });

            req.end();
        });

        return res.status(200).json({ status: true, data: result });

    } catch (err) {
        console.error("Error in getDnacSites:", err);
        return res.status(500).json({ msg: "Internal Server Error", error: err.message, status: false });
    }
};


















// export const insertDeviceInDnac = async (req, res) => {
//     try {
//         const db_connect = dbo && dbo.getDb();
//         let data = req.body
//         if (Object.keys(data.length == 0)) {
//             return res.json({
//                 msg: "Unable to get data from user.",
//                 status: false

//             })
//         }
//         let templateCount = await db_connect.collection("sequenceNumber").findOne({ "templateName": "commonTemplate" });
//         data["uniqueName"] = uuidv4();
//         data["accessDevice"] = "HTAINBLR14XXXDS002",
//             data["serialNumber"] = `CG-${templateCount.serialNumber + 1}`
//         let staticcommand = await db_connect.collection("showCommand").findOne({ "oem": userDefine_keys.oem });
//         let profileMappedData = {
//             "oemSelect": request_data.oem,
//             "familySelect": request_data.family,
//             "roleSelect": request_data.role,
//             "profileSelect": userDefine_keys.ticketName,
//             "connectivityType": request_data.connectivityType,
//             "deviceSelect": userDefine_keys.host,
//             "source_url": request_data.dnacUrl || "NA",
//             "uniqueName": userDefine_keys.uniqueName,
//             "serialNumber": userDefine_keys.serialNumber,
//             "processStatus": false,
//             "isGolden": false,
//             "instantExicute": false,
//             "excutationState": "Open",
//             "serviceNowTicketData": userDefine_keys["serviceNowTicketData"],
//             "finalConfig": [
//                 {
//                     "config": userDefine_keys["configuration_detail"],
//                     "device": userDefine_keys.host
//                 }
//             ],
//             "StaticPreCheck": staticcommand.defaultCommand,
//             "StaticPostCheck": staticcommand.defaultCommand,
//             createdAt: new Date(),
//             updatedAt: new Date(),
//         };
//         let profileMappedSaveData = await db_connect.collection("profilemap").insertOne(profileMappedData);
//         data["profileMappedCollectionRefID"] = profileMappedSaveData?.insertedId

//         let saveData = await onboardingModel(data);
//         await saveData.save()
//         let ticketStatus = {
//             "ticketName": userDefine_keys.ticketName,
//             "excuteStatus": false,
//             "fileType": "svi creation",
//             "host": userDefine_keys.host,
//             processStatus: false,
//             connectivityType: request_data.connectivityType,
//             "isGolden": false,
//             "source_url": request_data.dnacUrl || "NA",
//             ticketId: inbulid_keys.ticket_id || "NA",
//             ticketStatus: inbulid_keys.state || "NA",
//             "excutationState": "Open",
//             "oem": request_data.oem,
//             "role": request_data.role,
//             "family": request_data.family,
//             "connectivityType": request_data.connectivityType,
//             "uniqueName": userDefine_keys.uniqueName,
//             serialNumber: userDefine_keys.serialNumber,
//             "StaticPreCheck": staticcommand.defaultCommand,
//             StaticPostCheck: staticcommand.defaultCommand,
//             "nonDnac": userDefine_keys.nonDnac,
//             configuration: userDefine_keys["configuration_detail"],
//             "preMsg": [],
//             "postMsg": [],
//         };
//         let ticket_status = await ticket_status_data(ticketStatus)
//         let ticketIdDoc = {
//             "ticketName": userDefine_keys.ticketName,
//             "deviceId": userDefine_keys.host,
//             "oem": request_data.oem,
//             "connectivityType": request_data.connectivityType,
//             "isGolden": false,
//             "excutationState": "Open",
//             "serialNumber": userDefine_keys.serialNumber,
//             "source_url": request_data.dnacUrl || "NA",
//             "uniqueName": userDefine_keys.uniqueName,
//             "family": request_data.family,
//             "role": request_data.role,
//             "fileType": "svi creation",
//         }
//         let ticketIdCollection = await ticketIdModel.create(ticketIdDoc)
//         let updateTemplateCount = await db_connect.collection("sequenceNumber").updateOne({ "templateName": "commonTemplate" }, { $set: { serialNumber: templateCount.serialNumber + 1 } })
//         return res.send(saveData)

//     } catch (err) {
//         let errorMsg = { msg: `Error msg in insertDeviceInDnac:${err}`, status: false }
//         logger.error(errorMsg)
//         console.log(errorMsg)
//     }
// }