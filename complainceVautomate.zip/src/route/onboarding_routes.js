import express from "express";
import { onboardDeviceDetails,configDevicesInDnac,dnacDeviceInterfaces, getUnClaimedDevice, getDnacSites} from "../controller/Onboarding.js";
// import { authenticate, authorizeRoles} from '../../auth.js';
// import { dnacDataDetail, insertDeviceInDnac, onboardDeviceDetails } from "../controller/Onboarding_Portal/Onboarding.js";


const router = express.Router();

// //insert device in dnac
// router.post('/insertDevice',insertDeviceInDnac);
router.get('/onboardDeviceDetails',onboardDeviceDetails);
router.post('/configDeviceInDnac',configDevicesInDnac);
router.post('/dnacDeviceInterface',dnacDeviceInterfaces);
router.post('/getUnClaimedDevice',getUnClaimedDevice);
router.post('/getDnacSites',getDnacSites);




export default router