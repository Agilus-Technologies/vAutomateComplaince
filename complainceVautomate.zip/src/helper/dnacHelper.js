import https from "https";
import iconv from "iconv-lite";
// import iconv from "iconv-lite";
import { decript, encryptAES } from "../../helper.js";
import dbo from "../db/conn.js";
import axios from "axios";

export const db_config = async (req, res) => {
    try {
        let db_connect = dbo && dbo.getDb();
        let config = await db_connect.collection("vautomate_config").find({}).toArray();
        return config
    } catch (err) {
        console.log("Error in db_config ", err)

    }

}
export const getDnacToken = async (dnacCredentialsData) => {
    try {
        let hostName = dnacCredentialsData?.ip?.split("/");
        let aesEnabled = dnacCredentialsData?.aesAuthEnabled;
        const secretKey = dnacCredentialsData?.apiEncriptionKey
        let options;
        if (aesEnabled) {
            const username = dnacCredentialsData.username;
            const password = dnacCredentialsData.password;
            const auth = `${username}:${password}`;
            const cipherBase64 = encryptAES(auth, secretKey);
            options = {
                // hostname: hostName /* '10.122.1.25' */,
                hostname: hostName[2].toString() /* '10.122.1.25' */,
                path: dnacCredentialsData.authUrl,
                method: "POST",
                headers: {
                    Authorization: `CSCO-AES-256 credentials=${cipherBase64}`,
                },
                rejectUnauthorized: false
            };
        } else {
            options = {
                // hostname: hostName[1] /* '10.122.1.25' */,
                hostname: hostName[2].toString() /* '10.122.1.25' */,
                path: dnacCredentialsData.authUrl,
                method: "POST",
                rejectUnauthorized: false,
                headers: {
                    Authorization: "Basic " + Buffer.from(dnacCredentialsData.username + ":" + dnacCredentialsData.password).toString("base64"),
                },
            };
        };
        let result = await new Promise((resolve) => {
            var req = https.request(options, function (res) {
                // console.log("res",res)
                var data = [];
                res
                    .on("data", function (chunk) {
                        data.push(chunk);
                    })
                    .on("end", function () {
                        var buffer = Buffer.concat(data);
                        var str = iconv.decode(buffer, "windows-1252");

                        resolve(JSON.parse(str));
                    });
            });
            req.end();
            req.on("error", function (error) {
                if (error) {
                    return {
                        result: {

                            error: "ip is not valid.",
                            status: false,
                            tool: "DNA-C"
                        },
                    };
                }
                console.error("getting error is ", e);
            });
        });
        return result;
    } catch (err) {
        console.log("Error in getDnacToken in dnacHelper", err)
        let msg = `Error in getDnacToken in dnacHelper:${err}`
        let msg_output = { "msg": msg, status: false }
        return msg_output;
    }
};

export const commonCredentials = async (ip, dnacUrl = "") => {
    try {
        let db_connect = dbo && dbo.getDb()
        let config = await db_config();
        
        // let setUpDetails = await setUPModel.findOne({}).lean();
        // let dnacUrlss = await inventoryModel.find({ $and: [{ source: "dnac" }, { IP: ip }] });        
        // let dnacUrls = dnacUrl === "" ? dnacUrlss[0]._doc.source_url : dnacUrl 
        // let dnacUrls = dnacUrl === "" ? dnacUrlss[0].source_url : dnacUrl 
        let setUpDetails = await db_connect.collection('tbl_Package').find({}).project({ "dnac": 1, "_id": 0 }).toArray();
        let deviceUUId = await db_connect.collection('ms_device').find({ $and: [{ source: "DNAC" }, { managementIpAddress: ip }, { "source_url": dnacUrl }] }).toArray();
        let switchUUID = deviceUUId[0]?.device_id
        const { AUTH_API_URL, template_id } = config && config[0]?.dnac
        let dnacDetailss = setUpDetails[0]?.dnac.filter((item) => item?.DnacURL === dnacUrl)
        let cli_command_url = dnacDetailss[0]?.DnacURL + config[0]?.dnac?.cli_command_read_request;
        let deploy_temp_url = dnacDetailss[0]?.DnacURL + config[0]?.dnac?.DEPLOY_TEMPLATE_URL;
        let temp_deploy_status_url = dnacDetailss[0]?.DnacURL + config[0]?.dnac?.TEMPLATE_STATUS;
        let interfaceAPi = dnacDetailss[0]?.DnacURL + config[0]?.dnac?.interfaceEndPoint + switchUUID;
        // console.log("cli_command_url",cli_command_url)
        let dnacCredentials = {
            authUrl: AUTH_API_URL,
            ip: dnacDetailss[0]?.DnacURL,
            username: dnacDetailss[0]?.DnacUserName,
            password: decript(dnacDetailss[0]?.DnacPassWord),
            aesAuthEnabled: dnacDetailss[0]?.is_aes_auth || false,
            apiEncriptionKey: dnacDetailss[0]?.secret_key || ""
        }
        let token = await getDnacToken(dnacCredentials);
        token = token?.Token
        // if(token){
        let obj = {
            token: token,
            dnacCredentials,
            cli_command_url,
            deploy_temp_url,
            temp_deploy_status_url,
            AUTH_API_URL,
            switchUUID,
            interfaceAPi,
            dnacUrl: dnacDetailss[0]?.dnacUrl,
            template_id
        }
        return obj;
        // }
    } catch (err) {
        console.log("Error in commanCredentials in dnacHelper", err)
        let msg = `Error in commanCredentials in dnacHelper:${err}`
        let msg_output = { "msg": msg, status: false }
        return msg_output;
    }
}