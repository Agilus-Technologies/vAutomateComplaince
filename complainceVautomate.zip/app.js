import express from "express";
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import fs from "fs";
import https from "https";
import onboardingRoute from "./src/route/onboarding_routes.js";
import cors from 'cors';
import morgan from 'morgan';
import session from 'express-session';
import fileUpload from "express-fileupload";
import rateLimit from 'express-rate-limit';
import logger from "./logger.js";
import dbo from "./src/db/conn.js";

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

// Reading the key and certificate for HTTPS
const options = {
    key: fs.readFileSync("key.pem"),
    cert: fs.readFileSync("certificate.pem"),
};

// Middleware setup
app.use(express.static('./public'));
app.use(cors());

// Rate limiting
const limiter = rateLimit({
    windowMs: 3 * 60 * 1000, // 3 minutes
    max: 200, // Max 200 requests per IP in this window
    message: 'Too many requests from this IP, please try again later.',
    headers: true,
});
app.use(limiter);

// File upload configuration
app.use(fileUpload({
    useTempFiles: true,
    tempFileDir: '/tmp/'
}));

// Session configuration
app.use(session({
    secret: 'SECRET_KEY',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 },
}));

// Logging configuration with Morgan
morgan.token('statusCode', (req, res) => res.statusCode);
app.use(morgan('tiny', {
    stream: {
        write: (message) => logger.info(message.trim()),
    },
}));

// Middleware to allow cross-origin requests
app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});

// Routes
app.use('/api/v1/onboard', onboardingRoute);

// MongoDB connection
const connectToDb = async () => {
    try {
        await dbo?.connectToServer("", "", function (err) {
            if (err) console.error("error in db", err);
        });
        // console.log('Connected to the database');
    } catch (err) {
        console.error('Error connecting to database:', err);
    }
};

// Start the server after DB connection
const startServer = async() => {
    const server = https.createServer(options, app);
   
    server.listen(port, () => {
        console.log(`HTTPS server running on https://localhost:${port}`);
    });
};

// Initiate the MongoDB connection and then start the server
connectToDb().then(() => startServer()).catch((err) => {
    console.error('Error starting server:', err);
});
